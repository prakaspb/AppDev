from ai.llm_engine import LLMEngine
from ai.content_analyzer import ContentAnalyzer
from ai.pdf_reader import PDFReader
from database.progress_db import ProgressDB
from scheduler.spaced_repetition import SpacedRepetition
from core.adaptive_engine import AdaptiveEngine

class SmartStudyBuddy:

    def __init__(self):
        self.llm = LLMEngine()
        self.analyzer = ContentAnalyzer()
        self.pdf_reader = PDFReader()
        self.db = ProgressDB()
        self.scheduler = SpacedRepetition()
        self.adaptive = AdaptiveEngine()

    def study_from_pdf(self, pdf_path, style):
        #  READ TEXTBOOK PDF ( reads the PDF and extracts the text content for analysis)
        text = self.pdf_reader.read_pdf(pdf_path)

        # ✅ NLP CONCEPT EXTRACTION
        concepts = self.analyzer.extract_concepts(text)

        for concept in concepts:
            print(f"\n📘 Concept: {concept}")

            mastery = self.db.get_mastery(concept)
            difficulty = self.adaptive.decide_difficulty(mastery)

            question = self.llm.generate_question(concept, difficulty)
            print("\n❓", question)

            user_answer = input("✍️ Your answer (or type 'exit' to stop): ")

            if user_answer.lower() == "exit":
                print("👋 Exiting study session.")
                break

            score = int(input("✅ Score yourself (1–10): "))
            mastery = score / 10

            explanation = self.llm.explain(concept, style)
            print("💡", explanation)

            self.db.update(concept, mastery)
            print("📅", self.scheduler.schedule(mastery))
    
        print("\n✅ Study session completed successfully.")
        print("📊 Your progress has been saved.")