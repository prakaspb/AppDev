class AdaptiveEngine:
    def decide_difficulty(self, mastery):
        if mastery >= 0.8: return 'hard'
        elif mastery >= 0.5: return 'medium'
        return 'easy'