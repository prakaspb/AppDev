from ai.llm_engine import LLMEngine
from ai.content_analyzer import ContentAnalyzer
from ai.pdf_reader import PDFReader
from database.progress_db import ProgressDB
from scheduler.spaced_repetition import SpacedRepetition
from core.adaptive_engine import AdaptiveEngine

class SmartStudyBuddy:

    def __init__(self):
        self.llm = LLMEngine()
        self.analyzer = ContentAnalyzer()
        self.pdf_reader = PDFReader()
        self.db = ProgressDB()
        self.scheduler = SpacedRepetition()
        self.adaptive = AdaptiveEngine()

    def study_from_pdf(self, pdf_path, style):
        # ✅ READ TEXTBOOK PDF
        text = self.pdf_reader.read_pdf(pdf_path)

        # ✅ NLP CONCEPT EXTRACTION
        concepts = self.analyzer.extract_concepts(text)

        for concept in concepts:
            mastery = self.db.get_mastery(concept)
            difficulty = self.adaptive.decide_difficulty(mastery)

            question = self.llm.generate_question(concept, difficulty)
            print("\n❓", question)

            input("✍️ Your answer: ")
            score = int(input("✅ Score yourself (1–10): "))
            mastery = score / 10

            explanation = self.llm.explain(concept, style)
            print("💡", explanation)

            self.db.update(concept, mastery)
            print("📅", self.scheduler.schedule(mastery))