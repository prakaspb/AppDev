class SpacedRepetition:
    def schedule(self, mastery):
        if mastery >= 0.8: return 'You can review after 7 days'
        elif mastery >= 0.5: return 'You can review after 3 days'
        return 'Recommending yoo to review tomorrow'