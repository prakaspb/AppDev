from core.study_buddy import SmartStudyBuddy

def main():
    buddy = SmartStudyBuddy()

    while True:
        print("E:\Prakash\Project_Silver\AISmartStudy\physics_high_school.pdf\n🎓 Smart Study Buddy")
        print("1. Study from PDF")
        print("2. View progress")
        print("3. Exit")

        choice = input("👉 Choose an option (1/2/3): ")

        if choice == "1":
            pdf_path = input("📄 Enter PDF file path: ")
            style = input("🎨 Learning style (visual/auditory/kinesthetic): ")
            buddy.study_from_pdf(pdf_path, style)

        elif choice == "2":
            buddy.db.show_progress()

        elif choice == "3":
            print("👋 Thank you for using Smart Study Buddy. Goodbye!")
            break

        else:
            print("❌ Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
