from core.study_buddy import SmartStudyBuddy

if __name__ == "__main__":
    buddy = SmartStudyBuddy()

    print("🎓 Smart Study Buddy (PDF Mode)")
    pdf_path = input("📄 Enter PDF file path: ")
    style = input("🎨 Learning style (visual/auditory/kinesthetic): ")

    buddy.study_from_pdf(pdf_path, style)