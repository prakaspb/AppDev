import PyPDF2

class PDFReader:
    def read_pdf(self, file_path):
        text = ""

        with open(file_path, "rb") as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                page_text = page.extract_text()
                #want to print the page              
                #print(f"📄 Page {page_num}:\n{page_text}\n"
                if page_text:
                    text += page_text + " "
        print(f'✅ Successfully read PDF: {file_path}')
        print(f'📄 Extracted Text:\n{text[:500]}...')  # Print first 500 characters for preview
        return text
 # The below code is for unit testing the PDFReader class. PDFReader.   
if __name__ == "__main__":
    pdf_reader = PDFReader()
    text = pdf_reader.read_pdf("E:\Prakash\Project_Silver\AISmartStudy\physics_high_school.pdf")
    print("\n📚 Extracted Text:\n", text[:500], "...")