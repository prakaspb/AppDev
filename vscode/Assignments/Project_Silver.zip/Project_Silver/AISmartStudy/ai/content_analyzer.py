import re

class ContentAnalyzer:
    def extract_concepts(self, text):
        words = re.findall(r'\b[a-zA-Z]{5,}\b', text.lower())
        return list(set(words))[:20]

# The below ocde is for Unit test for ContentAnalyzer 
if __name__ == "__main__":
    analyzer = ContentAnalyzer()
    #sample_text = "In physics, the concept of force is fundamental. A force can cause an object to accelerate. The formula F=ma describes this relationship."
    sample_text = "In physics, physics physics1 the concept of force is fundamental. A force can cause an object to accelerate. The formula F=ma describes this relationship."
    
    concepts = analyzer.extract_concepts(sample_text)
    print("Extracted Concepts:", concepts)