class LLMEngine:
    def generate_question(self, concept, difficulty):
        return f'[{difficulty}] Explain {concept}'
    def explain(self, concept, style):
        return f'[{style}] Explanation of {concept}'