import sqlite3
from datetime import date
class ProgressDB:
    def __init__(self):
        self.conn = sqlite3.connect('study_buddy.db')
        self.conn.execute('CREATE TABLE IF NOT EXISTS progress (concept TEXT PRIMARY KEY, mastery REAL, last_review DATE)')
    def update(self, concept, mastery):
        self.conn.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?)', (concept, mastery, date.today()))
        self.conn.commit()
    def get_mastery(self, concept):
        cur = self.conn.cursor(); cur.execute('SELECT mastery FROM progress WHERE concept=?', (concept,)); r=cur.fetchone(); return r[0] if r else 0.0
        
    #def show_progress(self):
     #   cur = self.conn.cursor()
      #  cur.execute("SELECT * FROM progress")
       # rows = cur.fetchall()

        #print("\n📊 Learning Progress")
        #for row in rows:
        #    print(f"Concept: {row[0]}, Mastery: {row[1]}, Last Reviewed: {row[2]}")

    def show_progress(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM progress")
        rows = cur.fetchall()

        print("\n📊 Learning Progress")
        for concept, mastery, last_review in rows:
            status = self.mastery_status(mastery)
            print(f"Concept: {concept}, Mastery: {mastery} ({status}), Last Reviewed: {last_review}")
            
    def mastery_status(self, mastery):
        if mastery >= 0.8:
            return "✅ Mastered"
        elif mastery >= 0.5:
            return "🟡 Needs Practice"
        else:
            return "🔴 Needs More Work"
    