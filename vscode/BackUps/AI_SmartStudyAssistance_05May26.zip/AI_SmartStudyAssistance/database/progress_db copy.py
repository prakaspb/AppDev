import sqlite3
from datetime import date

class ProgressDB:
    def __init__(self):
        self.c=sqlite3.connect('study.db')
        self.c.execute('CREATE TABLE IF NOT EXISTS progress(concept TEXT PRIMARY KEY, mastery REAL, last DATE)')
    def update(self,concept,mastery):
        self.c.execute('INSERT OR REPLACE INTO progress VALUES(?,?,?)',(concept,mastery,date.today()))
        self.c.commit()
    def get_mastery(self,concept):
        r=self.c.execute('SELECT mastery FROM progress WHERE concept=?',(concept,)).fetchone()
        return r[0] if r else 0.0
