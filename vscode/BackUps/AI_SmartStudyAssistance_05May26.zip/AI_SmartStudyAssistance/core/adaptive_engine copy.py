class AdaptiveEngine:
    def update(self, mastery, correct):
        return min(max(mastery+(0.1 if correct else -0.1),0),1)
