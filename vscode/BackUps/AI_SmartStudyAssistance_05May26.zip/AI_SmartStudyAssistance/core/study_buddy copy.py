from ai.llm_engine import LLMEngine
from core.adaptive_engine import AdaptiveEngine

from ai.pdf_reader import read_pdf
from ai.content_analyzer import ContentAnalyzer


class StudyBuddy:
    def __init__(self,db):
        self.db=db
        self.llm=LLMEngine()
        self.adapt=AdaptiveEngine()

    def study(self,concept):
        m=self.db.get_mastery(concept)
        explanation=self.llm.chat(f"Explain {concept} at level {m}")
        print(explanation)
        correct=input('Correct? y/n:')=='y'
        new=self.adapt.update(m,correct)
        self.db.update(concept,new)


    #def ingest_material(self,path):
     #   text=read_pdf(path)
      #  concepts=self.analyzer.extract_concepts(text)
       # for c in concepts:
        #    self.db.add_concept(c)
            
    def ingest_material(self, file_path):
        text = read_pdf(file_path)
        analyzer = ContentAnalyzer()
        concepts = analyzer.extract_concepts(text)
        return concepts