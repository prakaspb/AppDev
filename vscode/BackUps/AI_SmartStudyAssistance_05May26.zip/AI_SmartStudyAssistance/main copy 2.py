from database.progress_db import ProgressDB
from core.study_buddy import StudyBuddy

import logging
from logger_config import setup_logger




def main():
    print("\n📚 Welcome to AI Smart Study Buddy")

    # Initialize database and study buddy
    db = ProgressDB()
    study_buddy = StudyBuddy(db)

    # Step 1: Ingest study material
    file_path = input("\nEnter PDF path: ").strip()

    try:
        concepts = study_buddy.ingest_material(file_path)
    except Exception as e:
        print(f"\n❌ Failed to read or analyze the file: {e}")
        return

    if not concepts:
        print("\n⚠️ No concepts could be extracted.")
        return

    # Step 2: Display extracted concepts
    print("\n📌 Extracted concepts:")
    for idx, concept in enumerate(concepts, start=1):
        print(f"{idx}. {concept}")

    # Step 3: Interactive study loop
    while True:
        print("\nOptions:")
        print("1. Study a concept")
        print("2. View progress")
        print("3. Exit")

        choice = input("Select an option: ").strip()

        if choice == "1":
            concept = input("Enter concept name (or number): ").strip()

            # Allow numeric or text selection
            if concept.isdigit():
                index = int(concept) - 1
                if 0 <= index < len(concepts):
                    concept = concepts[index]
                else:
                    print("Invalid concept number.")
                    continue

            study_buddy.study_concept(concept)

        elif choice == "2":
            db.show_progress()

        elif choice == "3":
            print("\n✅ Exiting AI Smart Study Buddy. Happy learning!")
            break

        else:
            print("Invalid option. Try again.")


if __name__ == "__main__":
    main()1