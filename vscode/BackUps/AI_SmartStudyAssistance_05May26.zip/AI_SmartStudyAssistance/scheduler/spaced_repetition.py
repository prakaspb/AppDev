from datetime import timedelta

def interval(m):
    return timedelta(days=1 if m<0.5 else 3)
