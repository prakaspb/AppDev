from database.progress_db import ProgressDB
from core.study_buddy import StudyBuddy

if __name__=='__main__':
    db=ProgressDB()
    sb=StudyBuddy(db)
    c=input('Concept: ')
    sb.study(c)

